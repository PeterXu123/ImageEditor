/**
 * This class provides two general algorithms for ImageModel2D that are filter algorithm and
 * coloring algorithm.
 */
public class ImageOperation2D {

  /**
   * It is a general filter function with given filter that is two dimensional array and given image
   * data that is three dimensional array. It returns a three dimensional image data that has been
   * filtered with the filter.
   *
   * @param rgborigin original image data
   * @param filter the filter that is applied to the rgborigin
   * @return a three dimensional array, the new image data
   */
  public static int[][][] generalFilterAlgorithm(int[][][] rgborigin, double[][] filter) {
    int[][][] rgb = copy(rgborigin, rgborigin.length, rgborigin[0].length, rgborigin[0][0].length);
    int width = rgb[0].length;
    int height = rgb.length;
    int midpoint = filter.length / 2;
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        for (int channel = 0; channel < 3; channel++) {
          double value = 0;
          for (int filtery = 0; filtery < filter.length; filtery++) {
            for (int filterx = 0; filterx < filter[0].length; filterx++) {
              int realx = j - midpoint + filterx;
              int realy = i - midpoint + filtery;
              if (realx >= 0 && realy >= 0 && realx < width && realy < height) {

                value += filter[filtery][filterx] * rgborigin[realy][realx][channel];
              }
            }
          }

          rgb[i][j][channel] = (int) value;
        }
      }
    }

    return rgb;
  }

  /**
   * It creates a copy of given three dimensional array.
   *
   * @param origin the origin data
   * @param height the height
   * @param width the width
   * @param channel the channel number
   * @return a three dimensional array
   */
  public static int[][][] copy(int[][][] origin, int height, int width, int channel) {

    int[][][] output = new int[height][width][channel];
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        for (int c = 0; c < channel; c++) {
          output[i][j][c] = origin[i][j][c];
        }
      }
    }
    return output;
  }

  /**
   * It is general coloring method. It takes in a two dimensional colorVector and a given image data
   * (three dimensional array) and returns a image data that has been applied with colorVector.
   *
   * @param rgborigin the original image data
   * @param colorVector the color vector
   * @return a new image data
   */
  public static int[][][] generalColoringAlgorithm(int[][][] rgborigin, double[][] colorVector) {
    int[][][] rgb = copy(rgborigin, rgborigin.length, rgborigin[0].length, rgborigin[0][0].length);
    if (rgb[0][0].length != colorVector.length || rgb[0][0].length != colorVector[0].length) {
      throw new IllegalArgumentException("rgb channel number doesn't fit to colorVector size");
    } else {
      for (int channel = 0; channel < colorVector.length; channel++) {
        for (int row = 0; row < rgb.length; row++) {
          for (int col = 0; col < rgb[0].length; col++) {

            double[] tempColorOneDimensionVector = colorVector[channel];
            double value = -1;
            for (int i = 0; i < tempColorOneDimensionVector.length; i++) {
              value += (int) (tempColorOneDimensionVector[i] * rgb[row][col][i]);
            }
            if (value > 255) {
              value = 255;
            }
            if (value < 0) {
              value = 0;
            }
            rgb[row][col][channel] = (int) value;
          }
        }
      }
    }
    return rgb;
  }

  /**
   * It creates Dithering of the image with the given vector.
   *
   * @param rgborigin the origin image data
   * @param dVector the vector
   * @return a three dimensional array
   */
  public static int[][][] imageDithering(int[][][] rgborigin, double[] dVector) {
    int[][][] rgb = copy(rgborigin, rgborigin.length, rgborigin[0].length, rgborigin[0][0].length);
    int width = rgb[0].length;
    int height = rgb.length;
    for (int row = 0; row < height; row++) {
      for (int col = 0; col < width; col++) {
        for (int channel = 0; channel < 3; channel++) {
          int oldColor = rgb[row][col][channel];
          int newColor = (oldColor > 255 - oldColor) ? 255 : 0;
          int error = oldColor - newColor;
          rgb[row][col][0] = newColor;
          rgb[row][col][1] = newColor;
          rgb[row][col][2] = newColor;
          if (col + 1 < width) {
            rgb[row][col + 1][channel] = (int) (rgb[row][col + 1][channel] + dVector[0] * error);
            //            rgb[row][col + 1][1] = (int) (rgb[row][col + 1][1] + DVector[0] * error);
            //            rgb[row][col + 1][2] = (int) (rgb[row][col + 1][2] + DVector[0] * error);
          }
          if (col - 1 >= 0 && row + 1 < height) {
            rgb[row + 1][col - 1][channel] =
                (int) (rgb[row + 1][col - 1][channel] + dVector[1] * error);
            //            rgb[row + 1][col - 1][1] =
            //                    (int) (rgb[row + 1][col - 1][1] + DVector[1] * error);
            //            rgb[row + 1][col - 1][2] =
            //                    (int) (rgb[row + 1][col - 1][2] + DVector[1] * error);
          }
          if (row + 1 < height) {
            rgb[row + 1][col][channel] = (int) (rgb[row + 1][col][channel] + dVector[2] * error);
            //            rgb[row + 1][col][1] = (int) (rgb[row + 1][col][1] + DVector[2] * error);
            //            rgb[row + 1][col][2] = (int) (rgb[row + 1][col][2] + DVector[2] * error);
          }
          if (col + 1 < width && row + 1 < height) {
            rgb[row + 1][col + 1][channel] =
                (int) (rgb[row + 1][col + 1][channel] + dVector[3] * error);
            //            rgb[row + 1][col + 1][1] =
            //                    (int) (rgb[row + 1][col + 1][1] + DVector[3] * error);
            //            rgb[row + 1][col + 1][2] =
            //                    (int) (rgb[row + 1][col + 1][2] + DVector[3] * error);
          }
        }
      }
    }
    return rgb;
  }
}
