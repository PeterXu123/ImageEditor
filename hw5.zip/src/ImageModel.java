import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import images.ImageUtilities;

/**
 * It represents the abstract class of image model that implements the ImageModelInterface. It has
 * all image generation function including checkerboard, flags, and rainbow imageh generations.
 */
public class ImageModel implements ImageModelInterface {
  private int[][][] rgb;

  //  /** the stack that is used to store previous image data. */
  //  private final Stack<int[][][]> undoStack;
  //  /** the stack that is used to store current image before calling undo method. */
  //  private final Stack<int[][][]> redoStack;

  /**
   * It constructs image model with given image file path.
   *
   * @param filepath file path of the image
   * @throws IOException exception throw during read image
   */
  public ImageModel(String filepath) throws IOException {
    loadImage(filepath);
  }

  /**
   * It constructs AbstractImageGeneration class with given rgb. It just assigns the given rgb (a
   * three dimensional array) to the rgb of the model
   *
   * @param rgb a three dimensional array
   */
  public ImageModel(int[][][] rgb) {
    //    this.undoStack = new Stack<>();
    //    this.redoStack = new Stack<>();
    this.rgb = rgb;
    //    store();
  }

  /** This is the default constructor. It just assign default value to rgb of the model. */
  public ImageModel() {
    //    this.undoStack = new Stack<>();
    //    this.redoStack = new Stack<>();
    this.rgb = new int[1][1][3];
    //    store();
  }

  @Override
  public void generateRainbowStrips(int customHeight, int customWidth, boolean horizontal) {
    if (horizontal) {
      checkRainbowStrips(customHeight);
    } else {
      checkRainbowStrips(customWidth);
    }
    int[][][] answer = new int[customHeight][customWidth][3];
    List colorNumber = Arrays.asList(0, 1, 2, 3, 4, 5, 6);
    Collections.shuffle(colorNumber);
    HashMap<Integer, RBGColor> map1 = RBGColor.rainbowMap();
    int numRowForColor = (horizontal) ? customHeight / 7 : customWidth / 7;
    int needToAddLast = (horizontal) ? customHeight % 7 : customWidth % 7;
    int rowNumber = 0;
    int rth = 0;
    int rowl = -1;
    while (rth < 7) {
      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;

      while (rowNumber < ll) {
        if (horizontal) {
          for (int col = 0; col < customWidth; col++) {
            RBGColor rc = map1.get(colorNumber.get(rth));
            answer[rowNumber][col][0] = rc.getChannelOne();
            answer[rowNumber][col][1] = rc.getChannelTwo();
            answer[rowNumber][col][2] = rc.getChannelThree();
          }
        } else {
          for (int row = 0; row < customHeight; row++) {
            RBGColor rc = map1.get(colorNumber.get(rth));
            answer[row][rowNumber][0] = rc.getChannelOne();
            answer[row][rowNumber][1] = rc.getChannelTwo();
            answer[row][rowNumber][2] = rc.getChannelThree();
          }
        }
        rowNumber += 1;
      }
      rth += 1;
    }

    //    store();

    this.rgb = answer;

    //    return answer;
  }

  /**
   * It checked if heightOrWidth < 7. If so, it throws exception.
   *
   * @param heightOrWidth an integer
   */
  private void checkRainbowStrips(int heightOrWidth) {
    if (heightOrWidth < 7) {
      throw new IllegalArgumentException("rainbow has 7 colors at least.");
    }
  }

  /**
   * It is helper function for edgeDetection.
   * @param imageData three dimensional array
   * @return a three dimensional array
   */
  private int[][][] edgeDetectionHelper(int[][][] imageData) {
    double[][] kx = {{1.0, 0.0, -1.0}, {2.0, 0.0, -2.0}, {1.0, 0.0, -1.0}};
    double[][] ky = {{1.0, 2.0, 1.0}, {0.0, 0.0, 0.0}, {-1.0, -2.0, -1.0}};
    int[][][] gx = ImageOperation2D.generalFilterAlgorithm(imageData, kx);
    int[][][] gy = ImageOperation2D.generalFilterAlgorithm(imageData, ky);
    int[][][] output1 = new int[imageData.length][imageData[0].length][3];
    for (int i = 0; i < imageData.length; i++) {
      for (int j = 0; j < imageData[0].length; j++) {
        for (int c = 0; c < 3; c++) {
          output1[i][j][c] = (int) Math.sqrt(Math.pow(gx[i][j][c], 2) + Math.pow(gy[i][j][c], 2));
        }
      }
    }
    //    checkoutModify(output1);
    //    int[][][] output = ImageOperation2D.generalFilterAlgorithmVersion2(imageData, kx, ky);
    return output1;
  }

  /**
   * It returns an array that stores maximum values for each channel of the given image data.
   * @param imageData a three dimensional array
   * @return an array
   */
  private int[] maxValue(int[][][] imageData) {

    int[] output = new int[3];
    for (int channel = 0; channel < 3; channel++) {
      int maxV = Integer.MIN_VALUE;
      for (int row = 0; row < imageData.length; row++) {
        for (int col = 0; col < imageData[0].length; col++) {

          if (imageData[row][col][channel] >= maxV) {
            maxV = imageData[row][col][channel];
          }
        }
      }
      output[channel] = maxV;
    }
    return output;
  }

  /**
   * It returns an array that stores minimum values for each channel of the given image data.
   * @param imageData a three dimensional array
   * @return an array
   */
  private int[] minValue(int[][][] imageData) {
    int[] output = new int[3];
    for (int channel = 0; channel < 3; channel++) {
      int minV = Integer.MAX_VALUE;
      for (int row = 0; row < imageData.length; row++) {
        for (int col = 0; col < imageData[0].length; col++) {

          if (imageData[row][col][channel] <= minV) {
            minV = imageData[row][col][channel];
          }
        }
      }
      output[channel] = minV;
    }
    return output;
  }

  @Override
  public void highlightEdgeGrey() {
    int[][][] tempData = edgeDetectionHelper(this.rgb);
    int[] maxValue = maxValue(tempData);
    int[] minValue = minValue(tempData);
    if (Arrays.equals(maxValue, minValue)) {
      throw new IllegalArgumentException("can't generate Edge detection image");
    }
    System.out.println(maxValue);
    System.out.println(minValue);
    for (int row = 0; row < tempData.length; row++) {
      for (int col = 0; col < tempData[0].length; col++) {
        for (int channel = 0; channel < 3; channel++) {
          tempData[row][col][channel] =
              ((tempData[row][col][channel] - minValue[channel]) * 255)
                  / (maxValue[channel] - minValue[channel]);
        }
      }
    }
    this.rgb = tempData;
    imageGreyScale();
  }

  @Override
  public void generateCheckerboard(int nsps, int size) {
    if (size < nsps) {
      throw new IllegalArgumentException(
          "can't generate a checkerboard with this" + " size, and the number of squares");
    }
    int windowWidth = size / nsps;
    int windowHeight = size / nsps;
    int extraCol = size % nsps;
    int extraRow = size % nsps;
    int rowNumber = 0;
    int colNumber = 0;
    int[][][] answer = new int[size][size][3];
    RBGColor black = new RBGColor(0, 0, 0);
    RBGColor white = new RBGColor(255, 255, 255);
    boolean drawBlack = true;

    while (rowNumber < size || colNumber < size) {
      if (extraRow > 0) {
        windowHeight = (size / nsps) + 1;
        extraRow -= 1;
      } else {
        windowHeight = (size / nsps);
      }
      boolean temp = drawBlack;
      for (int row = rowNumber; row < rowNumber + windowHeight; row++) {
        colNumber = 0;
        extraCol = size % nsps;
        while (colNumber < size) {
          if (extraCol > 0) {
            extraCol -= 1;
            windowWidth = (size / nsps) + 1;
          } else {
            windowWidth = (size / nsps);
          }

          for (int col = colNumber; col < colNumber + windowWidth; col++) {
            if (drawBlack) {
              answer[row][col][0] = black.getChannelOne();
              answer[row][col][1] = black.getChannelTwo();
              answer[row][col][2] = black.getChannelThree();
            } else {
              answer[row][col][0] = white.getChannelOne();
              answer[row][col][1] = white.getChannelTwo();
              answer[row][col][2] = white.getChannelThree();
            }
          }
          drawBlack = !drawBlack;
          colNumber = colNumber + windowWidth;
        }

        drawBlack = temp;
      }
      rowNumber = rowNumber + windowHeight;

      drawBlack = !drawBlack;
    }

    //    store();

    this.rgb = answer;
    //    return answer;
  }

  @Override
  public void loadImage(String inputFile) throws IOException {
    this.rgb = ImageUtilities.readImage(inputFile);
  }

  @Override
  public void storeImage(String outputFile) throws IOException {
    System.out.println("output " + outputFile);
    ImageUtilities.writeImage(this.rgb, this.getWidth(), this.getHeight(), outputFile);
  }

  @Override
  public void generateFranceFlag(int height) {
    int width = (int) (1.5 * height);
    if ((double) width / (double) height != 1.5) {
      throw new IllegalArgumentException("width/height != 1.5");
    }

    if (height < 3) {
      throw new IllegalArgumentException("FranceFlag needs bigger size");
    }
    int[][][] answer = new int[height][width][3];
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        if (col < width / 3) {
          answer[row][col][0] = 0;
          answer[row][col][1] = 0;
          answer[row][col][2] = 255;
        } else if (col >= width / 3 && col < (2 * width) / 3) {
          answer[row][col][0] = 255;
          answer[row][col][1] = 255;
          answer[row][col][2] = 255;
        } else {
          answer[row][col][0] = 255;
          answer[row][col][1] = 0;
          answer[row][col][2] = 0;
        }
      }
    }

    //    store();

    this.rgb = answer;
    //    return answer;
  }

  @Override
  public void generateSwitzerlandFlag(int height) {
    int width = (int) (1.0 * height);
    //    if ((double) width / (double) height != 2.0 / 2.0) {
    //      throw new IllegalArgumentException("SwitzerlandFlag proportion is not correct");
    //    }
    if (height < 32) {
      throw new IllegalArgumentException("SwitzerlandFlag needs bigger size");
    }

    int[][][] answer = new int[height][width][3];
    RBGColor white = new RBGColor(255, 255, 255);
    RBGColor red = new RBGColor(255, 0, 0);
    int numRowForColor = height / 32;
    int needToAddLast = height % 32;
    int rowNumber = 0;
    int rth = 0;
    int rowl = -1;
    while (rth < 32) {

      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < width; col++) {
          if (rth >= 6 && rth < 13 && col >= (13 * width / 32) && col < (19 * width / 32)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }
          if (rth >= 13 && rth < 19 && col >= (6 * width / 32) && col < (26 * width / 32)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }
          if (rth >= 19 && rth < 26 && col >= (13 * width / 32) && col < (19 * width / 32)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }

          answer[rowNumber][col][0] = red.getChannelOne();
          answer[rowNumber][col][1] = red.getChannelTwo();
          answer[rowNumber][col][2] = red.getChannelThree();
        }
        rowNumber += 1;
      }
      rth += 1;
    }

    //    store();

    this.rgb = answer;
    //    return answer;
  }

  @Override
  public void generateNorwayFlag(int height) {
    int width = (int) ((11.0 / 8.0) * height);
    if ((double) width / (double) height != 11.0 / 8.0) {
      throw new IllegalArgumentException("width/height != 11/8");
    }
    if (height < 16) {
      throw new IllegalArgumentException("NorwayFlag proportion is wrong");
    }
    int[][][] answer = new int[height][width][3];
    RBGColor blue = new RBGColor(0, 0, 255);
    RBGColor white = new RBGColor(255, 255, 255);
    RBGColor red = new RBGColor(255, 0, 0);
    int numRowForColor = height / 16;
    int needToAddLast = height % 16;
    int rowNumber = 0;
    int rth = 0;
    int rowl = 1;
    RBGColor colorToDraw = red;
    while (rth < 16) {

      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < width; col++) {
          if (((col >= (6 * width / 22.0)) && (col < (7.0 * width / 22.0)))
              || ((col >= (9 * width / 22.0)) && (col < (10.0 * width / 22.0)))) {
            if (rth < 6 || rth >= 10) {
              answer[rowNumber][col][0] = white.getChannelOne();
              answer[rowNumber][col][1] = white.getChannelTwo();
              answer[rowNumber][col][2] = white.getChannelThree();
              continue;
            }
          }
          if (((col >= 7.0 * width / 22.0) && (col < 9.0 * width / 22.0))) {
            if (rth < 6 || rth >= 10) {
              answer[rowNumber][col][0] = blue.getChannelOne();
              answer[rowNumber][col][1] = blue.getChannelTwo();
              answer[rowNumber][col][2] = blue.getChannelThree();
              continue;
            }

            if (rth == 6 || rth == 9) {
              answer[rowNumber][col][0] = blue.getChannelOne();
              answer[rowNumber][col][1] = blue.getChannelTwo();
              answer[rowNumber][col][2] = blue.getChannelThree();
              continue;
            }
          }

          answer[rowNumber][col][0] = colorToDraw.getChannelOne();
          answer[rowNumber][col][1] = colorToDraw.getChannelTwo();
          answer[rowNumber][col][2] = colorToDraw.getChannelThree();
        }
        rowNumber += 1;
      }
      rth += 1;
      if (rth < 6 || rth >= 10) {
        colorToDraw = red;
      }
      if ((rth == 6) || (rth == 9)) {
        colorToDraw = white;
      }
      if ((rth == 7) || (rth == 8)) {
        colorToDraw = blue;
      }
    }

    //    store();

    this.rgb = answer;
    //    return answer;
  }

  @Override
  public void generateGreeceFlag(int height) {
    int width = (int) (1.5 * height);

    if ((double) width / (double) height != 1.5) {
      throw new IllegalArgumentException("width/height != 1.5");
    }
    if (height < 9) {
      throw new IllegalArgumentException("GreeceFlag needs bigger size");
    }
    int[][][] answer = new int[height][width][3];
    RBGColor blue = new RBGColor(0, 0, 255);
    RBGColor white = new RBGColor(255, 255, 255);
    int numRowForColor = height / 9;
    int needToAddLast = height % 9;
    int rowNumber = 0;
    int rth = 0;
    int rowl = -1;
    boolean drawBlue = true;

    while (rth < 9) {

      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < width; col++) {
          if (rth == 0
              && drawBlue
              && (col >= (2.0 * width / 15.0))
              && (col < (3.0 * width / 15.0))) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }

          if (rth == 1 && !drawBlue && (col < (2 * width / 15.0))) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }

          if (rth == 1 && !drawBlue && col >= (3 * width / 15.0) && col < (5 * width / 15.0)) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }
          if (rth == 2 && drawBlue && col < (5 * width / 15.0)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }
          if (rth == 3 && !drawBlue && (col < (2 * width / 15.0))) {

            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }

          if (rth == 3 && !drawBlue && col >= (3 * width / 15.0) && col < (5 * width / 15.0)) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }
          if (rth == 4 && drawBlue && (col >= (2 * width / 15.0) && col < (3 * width / 15.0))) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }

          if (drawBlue) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();

          } else {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
          }
        }
        rowNumber += 1;
      }
      drawBlue = !drawBlue;
      rth += 1;
    }

    //    store();

    this.rgb = answer;
    //    return answer;
  }

  //
  //  @Override
  //  public void store() {
  //    if (undoStack.empty()
  //        || !Arrays.deepEquals(
  //            this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length), this.undoStack.peek()))
  // {
  //      this.undoStack.push(this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length));
  //    }
  //  }

  //  @Override
  //  public void undo() {
  //    if (!undoStack.empty()) {
  //      this.redoStack.push(this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length));
  //
  //      this.rgb = this.undoStack.pop();
  //    } else {
  //      throw new IllegalArgumentException("can't go back anymore");
  //    }
  //  }

  //  @Override
  //  public void redo() {
  //    if (!this.redoStack.empty()) {
  //      this.undoStack.push(this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length));
  //      this.rgb = this.redoStack.pop();
  //    } else {
  //      throw new IllegalArgumentException("can't go forward anymore");
  //    }
  //  }
  //
  private void checkoutModify(int[][][] data) {
    for (int i = 0; i < data.length; i++) {
      for (int j = 0; j < data[0].length; j++) {
        for (int c = 0; c < data[0][0].length; c++) {
          if (data[i][j][c] > 255) {
            data[i][j][c] = 255;
          }
          if (data[i][j][c] < 0) {
            data[i][j][c] = 0;
          }
        }
      }
    }
  }

  @Override
  public void imageBlur() {
    double[][] filter = new double[3][3];
    filter[0][0] = 1.0 / 16.0;
    filter[0][1] = 1.0 / 8.0;
    filter[0][2] = 1.0 / 16.0;
    filter[1][0] = 1.0 / 8.0;
    filter[1][1] = 1.0 / 4.0;
    filter[1][2] = 1.0 / 8.0;
    filter[2][0] = 1.0 / 16.0;
    filter[2][1] = 1.0 / 8.0;
    filter[2][2] = 1.0 / 16.0;

    //    store();

    this.rgb = ImageOperation2D.generalFilterAlgorithm(this.rgb, filter);
    checkoutModify(this.rgb);
    //    return this.getRgb();
  }

  @Override
  public void imageSharpening() {
    double[][] filter = {
      {-1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0},
      {-1.0 / 8.0, 1.0 / 4.0, 1.0 / 4.0, 1.0 / 4.0, -1.0 / 8.0},
      {-1.0 / 8.0, 1.0 / 4.0, 1.0, 1.0 / 4.0, -1.0 / 8.0},
      {-1.0 / 8.0, 1.0 / 4.0, 1.0 / 4.0, 1.0 / 4.0, -1.0 / 8.0},
      {-1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0}
    };
    //    store();
    this.rgb = ImageOperation2D.generalFilterAlgorithm(this.rgb, filter);
    checkoutModify(this.rgb);
    //    return this.getRgb();
  }

  @Override
  public void imageGreyScale() {
    double[][] matrix = {
      {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722}
    };

    //    store();
    this.rgb = ImageOperation2D.generalColoringAlgorithm(this.rgb, matrix);
    //    return this.getRgb();
  }

  @Override
  public void imageSepiaTone() {
    double[][] matrix = {
      {0.393, 0.769, 0.189},
      {0.349, 0.686, 0.168},
      {0.272, 0.534, 0.131}
    };

    //    store();
    this.rgb = ImageOperation2D.generalColoringAlgorithm(this.rgb, matrix);
    //    return this.getRgb();
  }

  @Override
  public void imageDithering() {
    imageGreyScale();
    double[] vector = {(7.0 / 16.0), (3.0 / 16.0), (5.0 / 16.0), (1.0 / 16.0)};
    this.rgb = ImageOperation2D.imageDithering(this.rgb, vector);
  }

  private int getHeight() {
    return this.rgb.length;
  }

  private int getWidth() {
    return this.rgb[0].length;
  }
}
