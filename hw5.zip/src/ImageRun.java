import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/** the main for taking input from the users. */
public class ImageRun {

  /**
   * the main function.
   *
   * @param args the arguments given by the users
   * @throws IOException throw exception if something wrong during reading
   */
  public static void main(String[] args) throws IOException {
    File file = new File(args[0]);
    //    System.out.println(args[0]);
    InputStream intputstream = new FileInputStream(file);
    //    InputStream intputstream = ImageRun1.class.getResourceAsStream(args[0]);
    //    System.out.println(intputstream);
    InputStreamReader inputStreamReader =
        new InputStreamReader(intputstream, Charset.forName("UTF-8"));
    ImageControllerInterface controller = new ImageController(inputStreamReader);
    controller.getControl((ImageModelInterface) new ImageModel());
  }
}
