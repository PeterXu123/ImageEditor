import java.io.IOException;
import java.util.Scanner;

import images.ImageUtilities;

/**
 * You can run the main function in this class.
 */
public class ImageRun {

  /**
   * This is the main function.
   * @param args args of the main function
   * @throws IOException throw expcetion if error happens during reading image
   */
  public static void main(String[] args) throws IOException {
    System.out.println("Please follow the instructions below.");
    while (true) {

      Scanner userInput = new Scanner(System.in);
      int firstAnswer = -1;
      int secondAnswer = -1;
      String imageName = null;
      String operationName = null;
      Boolean vertical = null;
      int checkerboardSize = -1;
      int numberSq = -1;
      int rainbowWidth = -1;
      int rainbowHeight = -1;
      int flagSize = -1;
      ImageModel2D m = new ImageModel2D();
      int[][][] rgb;
      while (true) {
        System.out.println(
            "Generate images or modify existing images."
                + " Enter 1 for Generate images. Enter 2 for modify existing images.");
        try {
          firstAnswer = Integer.parseInt(userInput.next());
          if (firstAnswer != 1 && firstAnswer != 2) {
            System.out.println(
                "improper input. please give correct input and follow the instruction.");
            continue;
          }
          break;
        } catch (Exception e) {
          System.out.println("please enter a number.");
        }
      }
      if (firstAnswer == 1) {

        while (true) {
          System.out.println(
              "Enter 1 for generating checkerboard. Enter 2 for generating flags. " +
                      "Enter 3 for generating rainbow.");
          try {
            secondAnswer = Integer.parseInt(userInput.next());
            if (secondAnswer != 1 && secondAnswer != 2 && secondAnswer != 3) {
              System.out.println("improper input for the options. Please follow the instruction.");
              continue;
            }
            break;

          } catch (Exception e) {
            System.out.println("please enter a number.");
          }
        }

        if (secondAnswer == 1) {
          while (true) {
            try {
              System.out.println("give size for the checkerboard that should be greater than 10.");
              checkerboardSize = Integer.parseInt(userInput.next());
              if (checkerboardSize < 10) {
                System.out.println(
                    "improper input for the size of checkerboard. Please follow the instruction");
                continue;
              }

              break;

            } catch (Exception e) {
              System.out.println("give enter a number.");
            }
          }
          while (true) {
            try {
              System.out.println(
                  "give the number of squares per side for the checkerboard that should be less " +
                          "than its size but greater than 2.");
              numberSq = Integer.parseInt(userInput.next());
              if (numberSq > checkerboardSize || numberSq < 2) {
                System.out.println(
                    "improper input for the number squares per side. The size you gave is "
                        + checkerboardSize
                        + ". Please follow the instruction");
                continue;
              }
              break;

            } catch (Exception e) {
              System.out.println("please enter a number");
            }
          }

          ImageUtilities.writeImage(
              m.generateCheckerboard(numberSq, checkerboardSize),
              checkerboardSize,
              checkerboardSize,
              "res/users/checkerboard.png");
          return;
        } else if (secondAnswer == 2) {
          int flagN = -1;
          while (true) {
            try {
              System.out.println(
                  "Enter 1 for France flag. Enter 2 for Greece flag. Enter 3 for Norway flag"
                      + ". Enter 4 for Switzerland flag");
              flagN = Integer.parseInt(userInput.next());
              if (flagN < 1 || flagN > 4) {
                System.out.println(
                    "improper input for flag option. Please follow the instruction.");
                continue;
              }
              break;
            } catch (Exception e) {
              System.out.println("please enter number for the flag option");
            }
          }
          while (true) {
            while (true) {
              try {
                System.out.println("give the height of flags that should be greater than 30");
                flagSize = Integer.parseInt(userInput.next());
                if (flagSize < 30) {
                  System.out.println(
                      "improper input for height of flags. Please follow the instruction.");
                  continue;
                }
                break;

              } catch (Exception e) {
                System.out.println(
                    "please enter number for the flag option, and number for height of the flag.");
              }
            }
            try {
              switch (flagN) {
                case 1:
                  rgb = m.generateFranceFlag(flagSize);
                  ImageUtilities.writeImage(
                      rgb, rgb[0].length, rgb.length, "res/users/Franceflag.png");
                  return;
                case 2:
                  rgb = m.generateGreeceFlag(flagSize);
                  ImageUtilities.writeImage(
                      rgb, rgb[0].length, rgb.length, "res/users/Greeceflag.png");
                  return;
                case 3:
                  rgb = m.generateNorwayFlag(flagSize);
                  ImageUtilities.writeImage(
                      rgb, rgb[0].length, rgb.length, "res/users/Norwayflag.png");
                  return;
                case 4:
                  rgb = m.generateSwitzerlandFlag(flagSize);
                  ImageUtilities.writeImage(
                      rgb, rgb[0].length, rgb.length, "res/users/Switzerlandflag.png");
                  return;
                default:
                  System.out.println("impossible line. An unknown error show up.");

                  return;
              }
            } catch (Exception e) {
              System.out.println(e.getMessage());
              System.out.println(
                  "The height you give doesn't fit for the proportion of the flag,"
                      + "please try another value based on the exception message shown above");
            }
          }

        } else {
          while (true) {
            String horv = null;
            System.out.println(
                "vertical or horizontal? Enter v for vertical. Enter h for horizontal");
            try {
              horv = userInput.next();
              if (!horv.equals("v") && !horv.equals("h")) {
                System.out.println("please give v or h. Follow instruction.");
                continue;
              }
              vertical = horv.equals("v");
              break;

            } catch (Exception e) {
              System.out.println(e.getMessage());
              continue;
            }
          }

          while (true) {
            System.out.println("give width and height of rainbow that should be greater than 20");
            try {
              rainbowWidth = Integer.parseInt(userInput.next());
              rainbowHeight = Integer.parseInt(userInput.next());
              if (rainbowWidth < 20 || rainbowHeight < 20) {
                System.out.println("rainbowWidth or rainbowHeight is less than 20");
                continue;
              }
              break;
            } catch (Exception e) {
              System.out.println("please give integer for rainbowWidth and rainbowHeight.");
            }
          }
          String temp = vertical ? "vertical" : "horizontal";
          rgb =
              vertical
                  ? m.generateVerticalRainbowStrips(rainbowHeight, rainbowWidth)
                  : m.generateHorizontalRainbowStrips(rainbowHeight, rainbowWidth);
          ImageUtilities.writeImage(
              rgb, rgb[0].length, rgb.length, "res/users/" + temp + "Rainbow.png");
          return;
        }
      } else {

        int usersAnswer = -1;

        while (true) {
          System.out.println("Choose file in users directory or Choose file locally. Enter 1 for " +
                  "choosing file in users directory. Enter 2" +
                  " for choosing file locally ");
          usersAnswer = Integer.parseInt(userInput.next());
          if (usersAnswer != 1 && usersAnswer != 2) {
            System.out.println("Please enter 1 or 2");
            continue;
          }
          break;
        }

        if (usersAnswer == 1) {

          while (true) {
            System.out.println(
                "choose files listed below \n" + "hohggkphlv.jpeg or manhattan-small.png");
            imageName = userInput.next();
            if (!imageName.equals("manhattan-small.png") && !imageName.equals("hohggkphlv.jpeg")) {
              continue;
            }
            break;
          }

          while (true) {
            System.out.println(
                "choose operations that lised below \n " + "blur \n sharpen \n grey \n sepiaTone ");
            operationName = userInput.next();
            if (!operationName.equals("blur")
                && !operationName.equals("sharpen")
                && !operationName.equals("grey")
                && !operationName.equals("sepiaTone")) {
              continue;
            }
            break;
          }
          if (operationName.equals("blur")) {
            int[][][] imageData = ImageUtilities.readImage("res/users/" + imageName);
            m = new ImageModel2D(imageData);
            ImageUtilities.writeImage(
                m.imageBlur(),
                m.getWidth(),
                m.getHeight(),
                "res/users/" + operationName + imageName);
            return;
          }
          if (operationName.equals("sharpen")) {
            int[][][] imageData = ImageUtilities.readImage("res/users/" + imageName);
            m = new ImageModel2D(imageData);
            ImageUtilities.writeImage(
                m.imageSharpening(),
                m.getWidth(),
                m.getHeight(),
                "res/users/" + operationName + imageName);
            return;
          }
          if (operationName.equals("grey")) {
            int[][][] imageData = ImageUtilities.readImage("res/users/" + imageName);
            m = new ImageModel2D(imageData);
            ImageUtilities.writeImage(
                m.imageGreyScale(),
                m.getWidth(),
                m.getHeight(),
                "res/users/" + operationName + imageName);
            return;
          }
          if (operationName.equals("sepiaTone")) {
            int[][][] imageData = ImageUtilities.readImage("res/users/" + imageName);
            m = new ImageModel2D(imageData);
            ImageUtilities.writeImage(
                m.imageSepiaTone(),
                m.getWidth(),
                m.getHeight(),
                "res/users/" + operationName + imageName);
            return;
          }
        }
        else {
          System.out.println("Enter your image path (absolute path)");
          try {
            String filePath = userInput.next();
            System.out.println(filePath);
            String suffix1 = filePath.split("\\.", 5)[1];
            int[][][] imageData = ImageUtilities.readImage(filePath);
            ImageModelInterface mm = new ImageModel2D(imageData);
            while (true) {
              System.out.println(
                      "choose operations that lised below \n " + "blur \n sharpen \n grey " +
                              "\n sepiaTone ");
              operationName = userInput.next();
              if (!operationName.equals("blur")
                      && !operationName.equals("sharpen")
                      && !operationName.equals("grey")
                      && !operationName.equals("sepiaTone")) {
                continue;
              }
              break;
            }
            if (operationName.equals("blur")) {
              ImageUtilities.writeImage(
                      mm.imageBlur(),
                      mm.getWidth(),
                      mm.getHeight(),
                      "res/users/" + operationName + "custom." + suffix1);
              return;
            }
            if (operationName.equals("sharpen")) {

              ImageUtilities.writeImage(
                      mm.imageSharpening(),
                      mm.getWidth(),
                      mm.getHeight(),
                      "res/users/" + operationName + "custom." + suffix1);
              return;
            }
            if (operationName.equals("grey")) {

              ImageUtilities.writeImage(
                      mm.imageGreyScale(),
                      mm.getWidth(),
                      mm.getHeight(),
                      "res/users/" + operationName + "custom." + suffix1);
              return;
            }
            if (operationName.equals("sepiaTone")) {

              ImageUtilities.writeImage(
                      mm.imageSepiaTone(),
                      mm.getWidth(),
                      mm.getHeight(),
                      "res/users/" + operationName + "custom." + suffix1);
              return;
            }

          }

          catch (Exception e) {
            System.out.println(e.getMessage());
            return;

          }
        }
      }
    }
  }
}
