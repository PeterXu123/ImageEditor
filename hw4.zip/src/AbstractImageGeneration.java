
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;


/**
 * It represents the abstract class of image model that implements the ImageModelInterface. It has
 * all image generation function including checkerboard, flags, and rainbow imageh generations.
 */
public abstract class AbstractImageGeneration implements ImageModelInterface {
  private int[][][] rgb;

  /** the stack that is used to store previous image data. */
  private final Stack<int[][][]> undoStack;
  /** the stack that is used to store current image before calling undo method. */
  private final Stack<int[][][]> redoStack;


  /**
   * It constructs AbstractImageGeneration class with given rgb.
   * It just assigns the given rgb (a three dimensional array) to the rgb of the model
   *
   * @param rgb a three dimensional array
   */
  public AbstractImageGeneration(int[][][] rgb) {
    this.undoStack = new Stack<>();
    this.redoStack = new Stack<>();
    this.rgb = rgb;
    store();
  }

  /** This is the default constructor. It just assign default value to rgb of the model. */
  public AbstractImageGeneration() {
    this.undoStack = new Stack<>();
    this.redoStack = new Stack<>();
    this.rgb = new int[600][600][3];
    store();
  }

  @Override
  public int[][][] generateHorizontalRainbowStrips(int customHeight, int customWidth) {
    checkRainbowStrips(customHeight);
    int[][][] answer = new int[customHeight][customWidth][3];
    List colorNumber = Arrays.asList(0, 1, 2, 3, 4, 5, 6);
    Collections.shuffle(colorNumber);
    HashMap<Integer, RBGColor> map1 = RBGColor.rainbowMap();
    int numRowForColor = customHeight / 7;
    int needToAddLast = customHeight % 7;
    int rowNumber = 0;
    int rth = 0;
    int rowl = -1;
    while (rth < 7) {
      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < customWidth; col++) {
          RBGColor rc = map1.get(colorNumber.get(rth));
          answer[rowNumber][col][0] = rc.getChannelOne();
          answer[rowNumber][col][1] = rc.getChannelTwo();
          answer[rowNumber][col][2] = rc.getChannelThree();
        }
        rowNumber += 1;
      }
      rth += 1;
    }

    store();

    this.rgb = answer;

    return answer;
  }

  /**
   * It checked if heightOrWidth < 7. If so, it throws exception.
   * @param heightOrWidth an integer
   */
  private void checkRainbowStrips(int heightOrWidth) {
    if (heightOrWidth < 7) {
      throw new IllegalArgumentException("rainbow has 7 colors at least.");
    }
  }

  @Override
  public int[][][] generateVerticalRainbowStrips(int customHeight, int customWidth) {
    checkRainbowStrips(customWidth);
    int[][][] answer = new int[customHeight][customWidth][3];
    List colorNumber = Arrays.asList(0, 1, 2, 3, 4, 5, 6);
    Collections.shuffle(colorNumber);
    HashMap<Integer, RBGColor> map1 = RBGColor.rainbowMap();
    int numColForColor = customWidth / 7;
    int needToAddLast = customWidth % 7;
    int colNumber = 0;
    int rth = 0;
    int coll = -1;
    while (rth < 7) {
      if (needToAddLast > 0) {
        coll = numColForColor + 1;
        needToAddLast -= 1;
      } else {
        coll = numColForColor;
      }
      int ll = colNumber + coll;
      while (colNumber < ll) {
        for (int row = 0; row < customHeight; row++) {
          RBGColor rc = map1.get(colorNumber.get(rth));
          answer[row][colNumber][0] = rc.getChannelOne();
          answer[row][colNumber][1] = rc.getChannelTwo();
          answer[row][colNumber][2] = rc.getChannelThree();
        }
        colNumber += 1;
      }
      rth += 1;
    }

    store();

    this.rgb = answer;
    return answer;
  }

  @Override
  public int[][][] generateCheckerboard(int nsps, int size) {
    if (size < nsps) {
      throw new IllegalArgumentException(
          "can't generate a checkerboard with this" + " size, and the number of squares");
    }
    int windowWidth = size / nsps;
    int windowHeight = size / nsps;
    int extraCol = size % nsps;
    int extraRow = size % nsps;
    int rowNumber = 0;
    int colNumber = 0;
    int[][][] answer = new int[size][size][3];
    RBGColor black = new RBGColor(0, 0, 0);
    RBGColor white = new RBGColor(255, 255, 255);
    boolean drawBlack = true;

    while (rowNumber < size || colNumber < size) {
      if (extraRow > 0) {
        windowHeight = (size / nsps) + 1;
        extraRow -= 1;
      } else {
        windowHeight = (size / nsps);
      }
      boolean temp = drawBlack;
      for (int row = rowNumber; row < rowNumber + windowHeight; row++) {
        colNumber = 0;
        extraCol = size % nsps;
        while (colNumber < size) {
          if (extraCol > 0) {
            extraCol -= 1;
            windowWidth = (size / nsps) + 1;
          } else {
            windowWidth = (size / nsps);
          }

          for (int col = colNumber; col < colNumber + windowWidth; col++) {
            if (drawBlack) {
              answer[row][col][0] = black.getChannelOne();
              answer[row][col][1] = black.getChannelTwo();
              answer[row][col][2] = black.getChannelThree();
            } else {
              answer[row][col][0] = white.getChannelOne();
              answer[row][col][1] = white.getChannelTwo();
              answer[row][col][2] = white.getChannelThree();
            }
          }
          drawBlack = !drawBlack;
          colNumber = colNumber + windowWidth;
        }

        drawBlack = temp;
      }
      rowNumber = rowNumber + windowHeight;

      drawBlack = !drawBlack;
    }

    store();

    this.rgb = answer;
    return answer;
  }

  @Override
  public int[][][] generateFranceFlag(int height) {
    int width = (int) (1.5 * height);
    if ((double) width / (double) height != 1.5) {
      throw new IllegalArgumentException("width/height != 1.5");
    }

    if (height < 3) {
      throw new IllegalArgumentException("FranceFlag needs bigger size");
    }
    int[][][] answer = new int[height][width][3];
    for (int col = 0; col < width; col++) {
      for (int row = 0; row < height; row++) {
        if (col < width / 3) {
          answer[row][col][0] = 0;
          answer[row][col][1] = 0;
          answer[row][col][2] = 255;
        } else if (col >= width / 3 && col < (2 * width) / 3) {
          answer[row][col][0] = 255;
          answer[row][col][1] = 255;
          answer[row][col][2] = 255;
        } else {
          answer[row][col][0] = 255;
          answer[row][col][1] = 0;
          answer[row][col][2] = 0;
        }
      }
    }

    store();

    this.rgb = answer;
    return answer;
  }

  @Override
  public int[][][] generateSwitzerlandFlag(int height) {
    int width = (int) (1.0 * height);
    //    if ((double) width / (double) height != 2.0 / 2.0) {
    //      throw new IllegalArgumentException("SwitzerlandFlag proportion is not correct");
    //    }
    if (height < 32) {
      throw new IllegalArgumentException("SwitzerlandFlag needs bigger size");
    }

    int[][][] answer = new int[height][width][3];
    RBGColor white = new RBGColor(255, 255, 255);
    RBGColor red = new RBGColor(255, 0, 0);
    int numRowForColor = height / 32;
    int needToAddLast = height % 32;
    int rowNumber = 0;
    int rth = 0;
    int rowl = -1;
    while (rth < 32) {

      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < width; col++) {
          if (rth >= 6 && rth < 13 && col >= (13 * width / 32) && col < (19 * width / 32)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }
          if (rth >= 13 && rth < 19 && col >= (6 * width / 32) && col < (26 * width / 32)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }
          if (rth >= 19 && rth < 26 && col >= (13 * width / 32) && col < (19 * width / 32)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }

          answer[rowNumber][col][0] = red.getChannelOne();
          answer[rowNumber][col][1] = red.getChannelTwo();
          answer[rowNumber][col][2] = red.getChannelThree();
        }
        rowNumber += 1;
      }
      rth += 1;
    }

    store();

    this.rgb = answer;
    return answer;
  }

  @Override
  public int[][][] generateNorwayFlag(int height) {
    int width = (int) ((11.0 / 8.0) * height);
    if ((double) width / (double) height != 11.0 / 8.0) {
      throw new IllegalArgumentException("width/height != 11/8");
    }
    if (height < 16) {
      throw new IllegalArgumentException("NorwayFlag proportion is wrong");
    }
    int[][][] answer = new int[height][width][3];
    RBGColor blue = new RBGColor(0, 0, 255);
    RBGColor white = new RBGColor(255, 255, 255);
    RBGColor red = new RBGColor(255, 0, 0);
    int numRowForColor = height / 16;
    int needToAddLast = height % 16;
    int rowNumber = 0;
    int rth = 0;
    int rowl = 1;
    RBGColor colorToDraw = red;
    while (rth < 16) {

      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < width; col++) {
          if (((col >= (6 * width / 22.0)) && (col < (7.0 * width / 22.0)))
              || ((col >= (9 * width / 22.0)) && (col < (10.0 * width / 22.0)))) {
            if (rth < 6 || rth >= 10) {
              answer[rowNumber][col][0] = white.getChannelOne();
              answer[rowNumber][col][1] = white.getChannelTwo();
              answer[rowNumber][col][2] = white.getChannelThree();
              continue;
            }
          }
          if (((col >= 7.0 * width / 22.0) && (col < 9.0 * width / 22.0))) {
            if (rth < 6 || rth >= 10) {
              answer[rowNumber][col][0] = blue.getChannelOne();
              answer[rowNumber][col][1] = blue.getChannelTwo();
              answer[rowNumber][col][2] = blue.getChannelThree();
              continue;
            }

            if (rth == 6 || rth == 9) {
              answer[rowNumber][col][0] = blue.getChannelOne();
              answer[rowNumber][col][1] = blue.getChannelTwo();
              answer[rowNumber][col][2] = blue.getChannelThree();
              continue;
            }
          }

          answer[rowNumber][col][0] = colorToDraw.getChannelOne();
          answer[rowNumber][col][1] = colorToDraw.getChannelTwo();
          answer[rowNumber][col][2] = colorToDraw.getChannelThree();
        }
        rowNumber += 1;
      }
      rth += 1;
      if (rth < 6 || rth >= 10) {
        colorToDraw = red;
      }
      if ((rth == 6) || (rth == 9)) {
        colorToDraw = white;
      }
      if ((rth == 7) || (rth == 8)) {
        colorToDraw = blue;
      }
    }

    store();

    this.rgb = answer;
    return answer;
  }

  @Override
  public int[][][] generateGreeceFlag(int height) {
    int width = (int) (1.5 * height);

    if ((double) width / (double) height != 1.5) {
      throw new IllegalArgumentException("width/height != 1.5");
    }
    if (height < 9) {
      throw new IllegalArgumentException("GreeceFlag needs bigger size");
    }
    int[][][] answer = new int[height][width][3];
    RBGColor blue = new RBGColor(0, 0, 255);
    RBGColor white = new RBGColor(255, 255, 255);
    int numRowForColor = height / 9;
    int needToAddLast = height % 9;
    int rowNumber = 0;
    int rth = 0;
    int rowl = -1;
    boolean drawBlue = true;

    while (rth < 9) {

      if (needToAddLast > 0) {
        rowl = numRowForColor + 1;
        needToAddLast -= 1;
      } else {
        rowl = numRowForColor;
      }
      int ll = rowNumber + rowl;
      while (rowNumber < ll) {
        for (int col = 0; col < width; col++) {
          if (rth == 0
              && drawBlue
              && (col >= (2.0 * width / 15.0))
              && (col < (3.0 * width / 15.0))) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }

          if (rth == 1 && !drawBlue && (col < (2 * width / 15.0))) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }

          if (rth == 1 && !drawBlue && col >= (3 * width / 15.0) && col < (5 * width / 15.0)) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }
          if (rth == 2 && drawBlue && col < (5 * width / 15.0)) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }
          if (rth == 3 && !drawBlue && (col < (2 * width / 15.0))) {

            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }

          if (rth == 3 && !drawBlue && col >= (3 * width / 15.0) && col < (5 * width / 15.0)) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();
            continue;
          }
          if (rth == 4 && drawBlue && (col >= (2 * width / 15.0) && col < (3 * width / 15.0))) {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
            continue;
          }

          if (drawBlue) {
            answer[rowNumber][col][0] = blue.getChannelOne();
            answer[rowNumber][col][1] = blue.getChannelTwo();
            answer[rowNumber][col][2] = blue.getChannelThree();

          } else {
            answer[rowNumber][col][0] = white.getChannelOne();
            answer[rowNumber][col][1] = white.getChannelTwo();
            answer[rowNumber][col][2] = white.getChannelThree();
          }
        }
        rowNumber += 1;
      }
      drawBlue = !drawBlue;
      rth += 1;
    }

    store();

    this.rgb = answer;
    return answer;
  }

  @Override
  public int[][][] getRgb() {
    return this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length);
  }

  @Override
  public void store() {
    if (undoStack.empty()
        || !Arrays.deepEquals(
            this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length), this.undoStack.peek())) {
      this.undoStack.push(this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length));
    }
  }

  protected int[][][] copy(int[][][] origin, int height, int width, int channel) {

    int[][][] copy = new int[height][width][channel];
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        for (int c = 0; c < channel; c++) {
          copy[i][j][c] = origin[i][j][c];
        }
      }
    }
    return copy;
  }

  @Override
  public void undo() {
    if (!undoStack.empty()) {
      this.redoStack.push(this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length));

      this.rgb = this.undoStack.pop();
    } else {
      throw new IllegalArgumentException("can't go back anymore");
    }
  }

  @Override
  public void redo() {
    if (!this.redoStack.empty()) {
      this.undoStack.push(this.copy(rgb, rgb.length, rgb[0].length, rgb[0][0].length));
      this.rgb = this.redoStack.pop();
    } else {
      throw new IllegalArgumentException("can't go forward anymore");
    }
  }

  public void setRgb(int[][][] rgb) {
    this.rgb = rgb;
  }
}
