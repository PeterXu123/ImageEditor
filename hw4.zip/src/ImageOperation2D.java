/**
 * This class provides two general algorithms for ImageModel2D that are filter algorithm and
 * coloring algorithm.
 */
public class ImageOperation2D {

  /**
   * It is a general filter function with given filter that is two dimensional array and given image
   * data that is three dimensional array. It returns a three dimensional image data that has been
   * filtered with the filter.
   *
   * @param rgborigin original image data
   * @param filter the filter that is applied to the rgborigin
   * @return a three dimensional array, the new image data
   */
  public static int[][][] generalFilterAlgorithm(int[][][] rgborigin, double[][] filter) {
    int[][][] rgb = rgborigin.clone();
    int width = rgb[0].length;
    int height = rgb.length;
    int midpoint = filter.length / 2;
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        for (int channel = 0; channel < 2; channel++) {
          double value = 0;
          for (int filtery = 0; filtery < filter.length; filtery++) {
            for (int filterx = 0; filterx < filter[0].length; filterx++) {
              int realx = j - midpoint + filterx;
              int realy = i - midpoint + filtery;
              if (realx >= 0 && realy >= 0 && realx < width && realy < height) {

                value += filter[filtery][filterx] * rgb[realy][realx][channel];
              }
            }
          }
          rgb[i][j][channel] = (int) value;
          if (rgb[i][j][channel] > 255) {
            rgb[i][j][channel] = 255;
          }
          if (rgb[i][j][channel] < 0) {
            rgb[i][j][channel] = 0;
          }
        }
      }
    }

    return rgb;
  }

  /**
   * It is general coloring method. It takes in a two dimensional colorVector and a given image data
   * (three dimensional array) and returns a image data that has been applied with colorVector.
   *
   * @param rgborigin the original image data
   * @param colorVector the color vector
   * @return a new image data
   */
  public static int[][][] generalColoringAlgorithm(int[][][] rgborigin, double[][] colorVector) {
    int[][][] rgb = rgborigin.clone();
    if (rgb[0][0].length != colorVector.length || rgb[0][0].length != colorVector[0].length) {
      throw new IllegalArgumentException("rgb channel number doesn't fit to colorVector size");
    } else {
      for (int channel = 0; channel < colorVector.length; channel++) {
        for (int row = 0; row < rgb.length; row++) {
          for (int col = 0; col < rgb[0].length; col++) {

            double[] tempColorOneDimensionVector = colorVector[channel];
            double value = -1;
            for (int i = 0; i < tempColorOneDimensionVector.length; i++) {
              value += (int) (tempColorOneDimensionVector[i] * rgb[row][col][i]);
            }
            if (value > 255) {
              value = 255;
            }
            if (value < 0) {
              value = 0;
            }
            rgb[row][col][channel] = (int) value;
          }
        }
      }
    }
    return rgb;
  }
}
