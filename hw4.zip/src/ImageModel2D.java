

/**
 * This class represents a two dimensional Image model. It extends the abstractImageGeneration class
 * so that it also can generate images like country flags, rainbow and checkerboard. Besides, It can
 * convert image to blur, sharpen Greyscale and SepiaTone mode.
 */
public final class ImageModel2D extends AbstractImageGeneration {

  /**
   * It constructs ImageModel2D class with given rgb. It just assigns the given rgb (a three
   * dimensional array) to the rgb of the model
   *
   * @param rgb a three dimensional array
   */
  public ImageModel2D(int[][][] rgb) {
    super(rgb);
    //    undoStack = new Stack<>();
    //    redoStack = new Stack<>();
    //    undoStack.push(this.rgb.clone());
    //    this.undoStack = undoStack;
    //    this.redoStack = redoStack;

  }

  /** This is the default constructor. It just assign default value to rgb of the model. */
  public ImageModel2D() {
    super();
    //    undoStack = new Stack<>();
    //    redoStack = new Stack<>();
    ////    this.rgb = new int[600][600][3];
    //    undoStack.push(this.rgb.clone());
    //    this.undoStack = undoStack;
    //    this.redoStack = redoStack;
  }

  @Override
  public int[][][] imageBlur() {
    double[][] filter = new double[3][3];
    filter[0][0] = 1.0 / 16.0;
    filter[0][1] = 1.0 / 8.0;
    filter[0][2] = 1.0 / 16.0;
    filter[1][0] = 1.0 / 8.0;
    filter[1][1] = 1.0 / 4.0;
    filter[1][2] = 1.0 / 8.0;
    filter[2][0] = 1.0 / 16.0;
    filter[2][1] = 1.0 / 8.0;
    filter[2][2] = 1.0 / 16.0;

    store();

    this.setRgb(ImageOperation2D.generalFilterAlgorithm(this.getRgb(), filter));
    return this.getRgb();
  }

  @Override
  public int[][][] imageSharpening() {
    double[][] filter = {
      {-1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0},
      {-1.0 / 8.0, 1.0 / 4.0, 1.0 / 4.0, 1.0 / 4.0, -1.0 / 8.0},
      {-1.0 / 8.0, 1.0 / 4.0, 1.0, 1.0 / 4.0, -1.0 / 8.0},
      {-1.0 / 8.0, 1.0 / 4.0, 1.0 / 4.0, 1.0 / 4.0, -1.0 / 8.0},
      {-1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0}
    };
    store();
    this.setRgb(ImageOperation2D.generalFilterAlgorithm(this.getRgb(), filter));
    return this.getRgb();
  }

  @Override
  public int[][][] imageGreyScale() {
    double[][] matrix = {
      {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722}
    };

    store();
    this.setRgb(ImageOperation2D.generalColoringAlgorithm(this.getRgb(), matrix));
    return this.getRgb();
  }

  @Override
  public int[][][] imageSepiaTone() {
    double[][] matrix = {
      {0.393, 0.769, 0.189},
      {0.349, 0.686, 0.168},
      {0.272, 0.534, 0.131}
    };

    store();
    this.setRgb(ImageOperation2D.generalColoringAlgorithm(this.getRgb(), matrix));
    return this.getRgb();
  }

  @Override
  public int getHeight() {
    return this.getRgb().length;
  }

  @Override
  public int getWidth() {
    return this.getRgb()[0].length;
  }
}
