/**
 * This class represents the interface of the image model in the MVC pattern. It includes methods
 * that operates on the image data of the model, such as blur and sharpen, and also includes methods
 * that generate new images data like rainbows, flags, and checkerboard. data.
 */
public interface ImageModelInterface {
  /**
   * It generates a horizontal rainbow with given height and width. It also replaces the image data
   * of the model with the created rainbow data.
   *
   * @param customHeight the height of the image
   * @param customWidth the width of the image
   * @return a three dimensional array (height, row, channel) that represents the data of the
   *     rainbow
   */
  int[][][] generateHorizontalRainbowStrips(int customHeight, int customWidth);

  /**
   * It generates a vertical rainbow with given height and width. It also replaces the image data of
   * the model with the created rainbow data.
   *
   * @param customHeight the height of the image
   * @param customWidth the width of the image
   * @return a three dimensional array (height, row, channel) that represents the data of the
   *     rainbow
   */
  int[][][] generateVerticalRainbowStrips(int customHeight, int customWidth);

  /**
   * It generates the image data that represents the blur version of the image in the model. It also
   * replaces the previous image data with this generated one.
   *
   * @return a three dimensional array (height, row, channel) that represents the blur image
   */
  int[][][] imageBlur();

  /**
   * It generates the image data that represents the sharpening version of the image in the model.
   * It also replaces the previous image ata with this new data.
   *
   * @return a three dimensional array (height, row, channel) that represents the sharpening image
   */
  int[][][] imageSharpening();

  /**
   * It generates the greyscale image data from the image data in the model and also replaces the
   * previous image data in the model with this one.
   *
   * @return a three dimensional array that represents the greyscale image data
   */
  int[][][] imageGreyScale();

  /**
   * It generates the SepiaTone image data from the image data in the model.
   *
   * @return a three dimensional array that represents the SepiaTone image data
   */
  int[][][] imageSepiaTone();

  /**
   * It generates the France flag image data with given height and width and take the place of
   * previous image data of the model.
   *
   * @param height the height of the flag
   * @return a three dimensional array that represents the flag
   */
  int[][][] generateFranceFlag(int height);

  /**
   * It generates the Switzerland flag image data with given height and width and take the place of
   * previous image data of the model.
   *
   * @param height the height of the flag
   * @return a three dimensional array that represents the flag
   */
  int[][][] generateSwitzerlandFlag(int height);

  /**
   * It generates the Norway flag image data with given height and width and take the place of
   * previous image data of the model.
   *
   * @param height the height of the flag
   * @return a three dimensional array that represents the flag
   */
  int[][][] generateNorwayFlag(int height);

  /**
   * It generates the Greece flag image data with given height and width and take the place of
   * previous image data of the model.
   *
   * @param height the height of the flag
   * @return a three dimensional array that represents the flag
   */
  int[][][] generateGreeceFlag(int height);

  /**
   * It generates a checkerboard image with given number of squares per side and the image size, and
   * the new image data will replace the old one.
   *
   * @param nsps the number of squares per side
   * @param size the image size of the checkerboard
   * @return a three dimensional array that represents the checkerboard
   */
  int[][][] generateCheckerboard(int nsps, int size);

  /**
   * It returns the height of the image data of the model.
   *
   * @return an integer
   */
  int getHeight();

  /**
   * It returns the width of the image data of the model.
   *
   * @return an integer
   */
  int getWidth();

  /** It undo the previous operation on the image. */
  void undo();

  /** It redo the operation on the image. */
  void redo();

  /** It stores the current images into undo stack. */
  void store();

  /**
   * It returns the clone of image data of the model.
   *
   * @return a three dimensional array
   */
  int[][][] getRgb();

  /**
   * It changes the image model data to the new data rgb.
   *
   * @param rgb the new image data
   */
  void setRgb(int[][][] rgb);
}
