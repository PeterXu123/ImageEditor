Before introducing you to my main function, I would like to introduce you to my three directories 
and their sub-directories.  There are three directories that are res, src and test directory. In 
res directory, there are 6 sub-directories. You can probably know what each sub-directory contains 
just based on their names. "users" directory will be used when you run the main function that is in
ImageRun file. There are two images in users that are original images for all images in 
OnePunchImage and Manhattan images. When you run the main function, and choose to modify existing 
images, you will have to pick/load a image in "users" directory. If you want to add your own image, 
you can add the image to "users" directory. All created images will be stored in users directory.

Now, let's talk about how to run the main function. You can run it in ImageRun file that is located
in src directory. The instruction I give is very specific. You know what to give even without 
reading this file. After you click run, you will need to enter 1 or 2. 1 represents the option of 
generating images. 2 represents the option of modifying existing images in "users" directory. 
If you pick generating images,  you will see this line "Enter 1 for generating checkerboard. Enter
 2 for generating flags. Enter 3 for generating rainbow." You have three options here (checkerboard
 , flags, and rainbows. If you enter 1, you will be asked to give the size of the checkerboard. The
 size you give should be greater than 10. After giving the size, you will be asked to give the 
 number of squares per side. Your input should be greater than 2. If you give correct input for 
 the size of checkerboard, and the number of squares per side, you will see the new image created in 
 users directory. If you give wrong input, you will be asked to enter the input again.
  
  If you choose to generate flags, you will be asked to enter a number that represents
 which flag you want to generate. The instruction line you will see is "Enter 1 for France flag. 
 Enter 2 for Greece flag. Enter 3 for Norway flag. Enter 4 for Switzerland flag". After choosing a
 flag, you will be asked to give a height for the flag that should be greater than 30. There is a
 very important thing you should know. Each flag has its proportion. If the height you give cannot
 produce a proper width, you will be asked to give a correct one. For example, the proportion of
 Norway flag is 11/8 = width / height. If you give 32 as its height, its width will be 44. However, 
 if you give 33, the width will be 45.375 that is not an integer. For this case, you will be asked 
 to give reasonable height. You will see the proportion of each flag once you give improper height.
 
 If you choose to generate rainbow, you will be asked which rainbow you want to create. The opiton
 you have includes vertical rainbow and horizontal rainbow. You enter v for vertical rainbow, and enter
 h for horizontal rainbow. Once you choose one, you will be asked to give width and height of the rainbow
 that both should be greater than 20. you will give width and height at the same time ("Enter a integer,
 press enter key, and enter another integer, press enter key again"). You will be asked to enter
 inputs if one of them is less than 20.
 
Now, if you enter 2 for modifying existing images, you will be asked if you want to load image 
from your local or from "users" directory. If you choose enter 1 that represents loading image from "users",
you see the line "choose files listed below hohggkphlv.jpeg or manhattan-small.png", 
you need to enter the file whole name like manhattan-small.png.
If you have added other images into users directory, you can enter the file's whole name in order to operation 
on the images. After entering the file name, you will see "blur, sharpen, grey, and sepiaTone". You 
will need to enter the name of operation to operate on the image you picked before. For exmaple, you will
enter "blur" if you want to blur the image you choose before. If you give wrong input, you will be asked
to enter again. If you enter 1 that represents loading image from local, you will be asked to provide 
absolute path of the image. After that, you will be asked to choose operation, and the rest is same. 
Image will be generated in "users" directory.
 
If you only want to see how those images in checkerboards, flags, Manhattan, OnePunchImage and rainbows,
you can delete those images on these sub-directories, but do not delete the sub-directories. Then,
you run the ImageModel2DTest. You would see images created under these sub-directory.

how to use images in "users" directory. All you need to give is the whole name of the file including
the suffix like JPG. Example user input: hohggkphlv.jpeg or manhattan-small.png.

how to use  images on your local (your laptop): you need to give the absolute path of the image
file. 


Citation of hohggkphlv.jpeg is from website https://www.0311xue.com/tuwen/5068577.html.

Citation of manhattan-small.png is from https://northeastern.instructure.com/courses/664/assignments/7596.

 
 
 

