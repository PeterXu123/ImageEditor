import org.junit.Test;

import java.io.IOException;

import images.ImageUtilities;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

/** This class is used to test imageModel class and its methods. */
public class ImageModel2DTest {

  @Test
  public void testConstructor() throws IOException {
    int[][][] testRbg = new int[5][5][5];
    ImageModel2D m = new ImageModel2D(testRbg);
    assertEquals(m.getHeight(), 5);
    assertEquals(m.getWidth(), 5);
    m = new ImageModel2D();
    assertEquals(m.getHeight(), 600);
    assertEquals(m.getWidth(), 600);
    int[][][] dataImage = ImageUtilities.readImage("res/users/hohggkphlv.jpeg");
    m = new ImageModel2D(dataImage);
    assertEquals(m.getWidth(), 700);
    assertEquals(m.getHeight(), 988);
  }

  @Test
  public void testGenerateHorizontalRainbowStrips() throws IOException {
    ImageModel2D m = new ImageModel2D();
    int[][][] rgb = m.generateHorizontalRainbowStrips(800, 1024);
    System.out.println(rgb[14][0][0]);
    System.out.println(rgb[14][0][1]);
    System.out.println(rgb[14][0][2]);
    System.out.println(rgb[15][0][0]);
    System.out.println(rgb[15][0][1]);
    System.out.println(rgb[15][0][2]);
    int[][][] rgb1 = rgb;
    ImageUtilities.writeImage(rgb1, 1024, 800, "res/Rainbows/"
            + "horizontalRainbow.png");
    assertNotNull(m);
  }

  @Test
  public void testGenerateVerticalRainbowStrips() throws IOException {
    ImageModel2D m = new ImageModel2D();
    int[][][] rgb = m.generateVerticalRainbowStrips(800, 1024);

    ImageUtilities.writeImage(rgb, 1024, 800, "res/Rainbows/"
            + "verticalRainbow.png");
    assertNotNull(m);
  }

  @Test
  public void testGenerateCheckerBoard() throws IOException {
    ImageModel2D m = new ImageModel2D();

    ImageUtilities.writeImage(
        m.generateCheckerboard(3, 1000), 1000, 1000,
            "res/Checkerboards/checkerboardsize3.png");
    ImageUtilities.writeImage(
        m.generateCheckerboard(5, 1000), 1000, 1000,
            "res/Checkerboards/checkerboardsize5.png");
    ImageUtilities.writeImage(
        m.generateCheckerboard(6, 1000), 1000, 1000,
            "res/Checkerboards/checkerboardsize6.png");
    assertNotNull(m);
  }

  @Test
  public void testBlur() throws IOException {
    int[][][] dataImage = ImageUtilities.readImage("res/Manhattan/manhattan-small.png");
    ImageModel2D m =  new ImageModel2D(dataImage);
    ImageUtilities.writeImage(
        m.imageBlur(), m.getWidth(), m.getHeight(),
            "res/Manhattan/manhattan-smallblur.png");

    int[][][] dataImage1 = ImageUtilities.readImage("res/OnePunchImage/hohggkphlv.jpeg");
    ImageModel2D m1 =  new ImageModel2D(dataImage1);
    ImageUtilities.writeImage(
            m1.imageBlur(), m1.getWidth(), m1.getHeight(),
            "res/OnePunchImage/hohggkphlvBlur.jpeg");
    assertNotNull(m);
    assertNotNull(m1);
  }

  @Test
  public void testsharpen() throws IOException {
    int[][][] dataImage = ImageUtilities.readImage("res/OnePunchImage/hohggkphlv.jpeg");
    ImageModel2D m =  new ImageModel2D(dataImage);
    ImageUtilities.writeImage(
            m.imageSharpening(), m.getWidth(), m.getHeight(),
            "res/OnePunchImage/hohggkphlvSharpen.jpeg");





    int[][][] dataImage1 = ImageUtilities.readImage("res/Manhattan/manhattan-small.png");
    ImageModel2D mm =  new ImageModel2D(dataImage1);
    ImageUtilities.writeImage(
            mm.imageSharpening(), mm.getWidth(), mm.getHeight(),
            "res/Manhattan/manhattan-smallSharpen.png");
    assertNotNull(m);
    assertNotNull(mm);
  }

  @Test
  public void testGrey() throws IOException {
    int[][][] imageData = ImageUtilities.readImage("res/Manhattan/manhattan-small.png");
    ImageModel2D m = new ImageModel2D(imageData);
    ImageUtilities.writeImage(
        m.imageGreyScale(), m.getWidth(), m.getHeight(),
            "res/Manhattan/manhattan-smallGrey.png");


    imageData = ImageUtilities.readImage("res/OnePunchImage/hohggkphlv.jpeg");
    ImageModel2D m1 = new ImageModel2D(imageData);
    ImageUtilities.writeImage(
        m1.imageGreyScale(),
        m1.getWidth(),
        m1.getHeight(),
        "res/OnePunchImage/hohggkphlvGrey.jpeg");
    assertNotNull(m);
    assertNotNull(m1);
  }

  @Test
  public void testSepiaTone() throws IOException {
    int[][][] imageData = ImageUtilities.readImage("res/Manhattan/manhattan-small.png");
    ImageModel2D m = new ImageModel2D(imageData);
    ImageUtilities.writeImage(
        m.imageSepiaTone(),
        m.getWidth(),
        m.getHeight(),
        "res/Manhattan/manhattan-smallSepiaTone.jpeg");

    imageData = ImageUtilities.readImage("res/OnePunchImage/hohggkphlv.jpeg");
    ImageModel2D m1 = new ImageModel2D(imageData);
    ImageUtilities.writeImage(
        m1.imageSepiaTone(),
        m1.getWidth(),
        m1.getHeight(),
        "res/OnePunchImage/hohggkphlvSepiaTone.jpeg");
    assertNotNull(m);
    assertNotNull(m1);
  }

  @Test
  public void testGenerateFranceFlag() throws IOException {
    ImageModel2D m = new ImageModel2D();
    int[][][] rgb = m.generateFranceFlag(400);
    ImageUtilities.writeImage(rgb, rgb[0].length, rgb.length, "res/Flags/FranceFlag.png");
    assertNotNull(m);
  }

  @Test
  public void testGenerateGreeceFlag() throws IOException {
    ImageModel2D m = new ImageModel2D();
    int[][][] rgb = m.generateGreeceFlag(400);
    System.out.println(m.getHeight());
    System.out.println(m.getWidth());
    ImageUtilities.writeImage(rgb, rgb[0].length, rgb.length, "res/Flags/GreeceFlag.png");
    assertNotNull(m);
  }

  @Test
  public void testGenerateNorwayFlag() throws IOException {
    ImageModel2D m = new ImageModel2D();
    int[][][] rgb = m.generateNorwayFlag(512);
    ImageUtilities.writeImage(rgb, rgb[0].length, rgb.length, "res/Flags/NorwayFlag.png");
    assertNotNull(m);
  }

  @Test
  public void testGenerateSwitzerlandFlag() throws IOException {

    ImageModel2D m = new ImageModel2D();
    int[][][] rgb = m.generateSwitzerlandFlag(500);
    ImageUtilities.writeImage(rgb, rgb[0].length, rgb.length,
            "res/Flags/SwitzerlandFlag.png");
    assertNotNull(m);
  }

  @Test
  public void testGetWidth() {
    ImageModel2D m = new ImageModel2D();
    assertEquals(600, m.getWidth());
  }

  @Test
  public void testGetHeight() {
    ImageModel2D m = new ImageModel2D();
    assertEquals(600, m.getHeight());
  }

  @Test
  public void testUndo() {
    ImageModel2D m = new ImageModel2D();
    m.generateCheckerboard(4, 500);
    assertEquals(m.getHeight(), 500);
    m.undo();
    assertEquals(m.getHeight(), 600);
  }

  @Test
  public void testRedo() {
    ImageModel2D m = new ImageModel2D();
    m.generateCheckerboard(4, 500);
    assertEquals(m.getHeight(), 500);
    m.undo();
    assertEquals(m.getHeight(), 600);
    m.redo();
    assertEquals(m.getHeight(), 500);
  }

  @Test
  public void testGetRbg() {
    ImageModel2D m = new ImageModel2D();
    assertEquals(m.getRgb().length, 600);
    int[][][] temp = m.getRgb();
    System.out.println(m.getRgb()[0][0][0]);
    temp[0][0][0] = -1;
    System.out.println(m.getRgb()[0][0][0]);
    assertNotEquals(temp[0][0][0], m.getRgb()[0][0][0]);
  }

  @Test
  public void testSetRbg() {
    ImageModel2D m = new ImageModel2D();
    assertEquals(m.getRgb().length, 600);
    int[][][] temp = m.getRgb();
    System.out.println(m.getRgb()[0][0][0]);
    temp[0][0][0] = -1;
    m.setRgb(temp);
    assertEquals(temp[0][0][0], m.getRgb()[0][0][0]);
    m.generateCheckerboard(4, 500);
    assertEquals(m.getHeight(), 500);
    m.undo();
    assertEquals(m.getHeight(), 600);
  }
}
